﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_altimeter_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_wind_text_text_img = ''
        let normal_uvi_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_second_separator_img = ''
        let idle_background_bg_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_step_current_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: 'grey480-new3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 43,
              y: 140,
              src: 'bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 98,
              y: 345,
              font_array: ["small_0.png","small_1.png","small_2.png","small_3.png","small_4.png","small_5.png","small_6.png","small_7.png","small_8.png","small_9.png"],
              padding: false,
              h_space: -1,
              invalid_image: 'weather_29.png',
              dot_image: 'digital1_point.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 158,
              y: 338,
              src: 'sunrise.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 264,
              y: 345,
              font_array: ["small_0.png","small_1.png","small_2.png","small_3.png","small_4.png","small_5.png","small_6.png","small_7.png","small_8.png","small_9.png"],
              padding: false,
              h_space: -1,
              invalid_image: 'weather_29.png',
              dot_image: 'digital1_point.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 234,
              y: 338,
              src: 'sunsetdown.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 191,
              y: 341,
              image_array: ["Moon_30_01.png","Moon_30_02.png","Moon_30_03.png","Moon_30_04.png","Moon_30_05.png","Moon_30_06.png","Moon_30_07.png","Moon_30_08.png","Moon_30_09.png","Moon_30_10.png","Moon_30_11.png","Moon_30_12.png","Moon_30_13.png","Moon_30_14.png","Moon_30_15.png","Moon_30_16.png","Moon_30_17.png","Moon_30_18.png","Moon_30_19.png","Moon_30_20.png","Moon_30_21.png","Moon_30_22.png","Moon_30_23.png","Moon_30_24.png","Moon_30_25.png","Moon_30_26.png","Moon_30_27.png","Moon_30_28.png","Moon_30_29.png","Moon_30_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 254,
              y: 108,
              font_array: ["small_0.png","small_1.png","small_2.png","small_3.png","small_4.png","small_5.png","small_6.png","small_7.png","small_8.png","small_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'weather_30.png',
              unit_tc: 'weather_30.png',
              unit_en: 'weather_30.png',
              negative_image: 'weather_29.png',
              invalid_image: 'weather_29.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 121,
              y: 108,
              font_array: ["small_0.png","small_1.png","small_2.png","small_3.png","small_4.png","small_5.png","small_6.png","small_7.png","small_8.png","small_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'weather_30.png',
              unit_tc: 'weather_30.png',
              unit_en: 'weather_30.png',
              negative_image: 'weather_29.png',
              invalid_image: 'weather_29.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 108,
              font_array: ["small_0.png","small_1.png","small_2.png","small_3.png","small_4.png","small_5.png","small_6.png","small_7.png","small_8.png","small_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'weather_30.png',
              unit_tc: 'weather_30.png',
              unit_en: 'weather_30.png',
              negative_image: 'weather_29.png',
              invalid_image: 'weather_29.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 172,
              y: 101,
              image_array: ["weather_0.png","weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_018.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 311,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 180,
              y: 311,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'procent_small.png',
              unit_tc: 'procent_small.png',
              unit_en: 'procent_small.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 127,
              y: 311,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 311,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 245,
              y: 311,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 148,
              y: 260,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              imperial_unit_sc: 'ml.png',
              imperial_unit_tc: 'ml.png',
              imperial_unit_en: 'ml.png',
              dot_image: 'decimal.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 231,
              y: 260,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 57,
              y: 260,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 215,
              month_startY: 52,
              month_sc_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              month_tc_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              month_en_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              month_zero: 1,
              month_space: -2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 152,
              y: 63,
              week_en: ["w_00.png","w_01.png","w_02.png","w_03.png","w_04.png","w_05.png","w_06.png"],
              week_tc: ["w_00.png","w_01.png","w_02.png","w_03.png","w_04.png","w_05.png","w_06.png"],
              week_sc: ["w_00.png","w_01.png","w_02.png","w_03.png","w_04.png","w_05.png","w_06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 170,
              day_startY: 52,
              day_sc_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              day_tc_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              day_en_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 260,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'procent.png',
              unit_tc: 'procent.png',
              unit_en: 'procent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 73,
              hour_startY: 140,
              hour_array: ["time_hour_1.png","time_hour_2.png","time_hour_3.png","time_hour_4.png","time_hour_5.png","time_hour_6.png","time_hour_7.png","time_hour_8.png","time_hour_9.png","time_hour_10.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 218,
              minute_startY: 140,
              minute_array: ["time_hour_1.png","time_hour_2.png","time_hour_3.png","time_hour_4.png","time_hour_5.png","time_hour_6.png","time_hour_7.png","time_hour_8.png","time_hour_9.png","time_hour_10.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 343,
              second_startY: 140,
              second_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              second_zero: 1,
              second_space: -1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 203,
              y: 150,
              src: 'bt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: 'black480_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 34,
              y: 202,
              src: 'alarm_aod.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 266,
              month_startY: 113,
              month_sc_array: ["digital4_aod_0.png","digital4_aod_1.png","digital4_aod_2.png","digital4_aod_3.png","digital4_aod_4.png","digital4_aod_5.png","digital4_aod_6.png","digital4_aod_7.png","digital4_aod_8.png","digital4_aod_9.png"],
              month_tc_array: ["digital4_aod_0.png","digital4_aod_1.png","digital4_aod_2.png","digital4_aod_3.png","digital4_aod_4.png","digital4_aod_5.png","digital4_aod_6.png","digital4_aod_7.png","digital4_aod_8.png","digital4_aod_9.png"],
              month_en_array: ["digital4_aod_0.png","digital4_aod_1.png","digital4_aod_2.png","digital4_aod_3.png","digital4_aod_4.png","digital4_aod_5.png","digital4_aod_6.png","digital4_aod_7.png","digital4_aod_8.png","digital4_aod_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 109,
              day_startY: 113,
              day_sc_array: ["digital4_aod_0.png","digital4_aod_1.png","digital4_aod_2.png","digital4_aod_3.png","digital4_aod_4.png","digital4_aod_5.png","digital4_aod_6.png","digital4_aod_7.png","digital4_aod_8.png","digital4_aod_9.png"],
              day_tc_array: ["digital4_aod_0.png","digital4_aod_1.png","digital4_aod_2.png","digital4_aod_3.png","digital4_aod_4.png","digital4_aod_5.png","digital4_aod_6.png","digital4_aod_7.png","digital4_aod_8.png","digital4_aod_9.png"],
              day_en_array: ["digital4_aod_0.png","digital4_aod_1.png","digital4_aod_2.png","digital4_aod_3.png","digital4_aod_4.png","digital4_aod_5.png","digital4_aod_6.png","digital4_aod_7.png","digital4_aod_8.png","digital4_aod_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 172,
              y: 114,
              week_en: ["digital5_aod_0.png","digital5_aod_1.png","digital5_aod_2.png","digital5_aod_3.png","digital5_aod_4.png","digital5_aod_5.png","digital5_aod_6.png"],
              week_tc: ["digital5_aod_0.png","digital5_aod_1.png","digital5_aod_2.png","digital5_aod_3.png","digital5_aod_4.png","digital5_aod_5.png","digital5_aod_6.png"],
              week_sc: ["digital5_aod_0.png","digital5_aod_1.png","digital5_aod_2.png","digital5_aod_3.png","digital5_aod_4.png","digital5_aod_5.png","digital5_aod_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 273,
              font_array: ["digital1_aod_0.png","digital1_aod_1.png","digital1_aod_2.png","digital1_aod_3.png","digital1_aod_4.png","digital1_aod_5.png","digital1_aod_6.png","digital1_aod_7.png","digital1_aod_8.png","digital1_aod_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 26,
              am_y: 181,
              am_sc_path: 'AM_aod.png',
              am_en_path: 'AM_aod.png',
              pm_x: 26,
              pm_y: 181,
              pm_sc_path: 'PM_aod.png',
              pm_en_path: 'PM_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 66,
              hour_startY: 164,
              hour_array: ["aod_0.png","aod_1.png","aod_2.png","aod_3.png","aod_4.png","aod_5.png","aod_6.png","aod_7.png","aod_8.png","aod_9.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 240,
              minute_startY: 164,
              minute_array: ["aod_0.png","aod_1.png","aod_2.png","aod_3.png","aod_4.png","aod_5.png","aod_6.png","aod_7.png","aod_8.png","aod_9.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 199,
              y: 147,
              src: 'digital9_10_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 302,
              y: 292,
              w: 63,
              h: 41,
              src: 'shortcut.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 243,
              y: 292,
              w: 47,
              h: 41,
              src: 'shortcut.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 44,
              y: 239,
              w: 97,
              h: 45,
              src: 'shortcut.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}