﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_digital_clock_img_time = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 63,
              hour_startY: 105,
              hour_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              hour_zero: 1,
              hour_space: -98,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 170,
              minute_startY: 105,
              minute_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              minute_zero: 1,
              minute_space: -98,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 224,
              day_startY: 191,
              day_sc_array: ["36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              day_tc_array: ["36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              day_en_array: ["36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 178,
              month_startY: 166,
              month_sc_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png"],
              month_tc_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png"],
              month_en_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 158,
              y: 190,
              week_en: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              week_tc: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              week_sc: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 243,
              font_array: ["53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png"],
              padding: false,
              h_space: -32,
              unit_sc: '63.png',
              unit_tc: '63.png',
              unit_en: '63.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 190,
              y: 235,
              image_array: ["65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 272,
              font_array: ["94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png"],
              padding: false,
              h_space: 0,
              unit_sc: '106.png',
              unit_tc: '106.png',
              unit_en: '106.png',
              negative_image: '105.png',
              invalid_image: '104.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 153,
              y: 308,
              font_array: ["107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png"],
              padding: false,
              h_space: -34,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 244,
              y: 243,
              font_array: ["117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png"],
              padding: false,
              h_space: -35,
              invalid_image: '127.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '128.png',
              second_centerX: 208,
              second_centerY: 208,
              second_posX: 35,
              second_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: '129.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 73,
              hour_startY: 100,
              hour_array: ["130.png","131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png"],
              hour_zero: 1,
              hour_space: -102,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 168,
              minute_startY: 101,
              minute_array: ["140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png","148.png","149.png"],
              minute_zero: 1,
              minute_space: -102,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 226,
              day_startY: 190,
              day_sc_array: ["163.png","164.png","165.png","166.png","167.png","168.png","169.png","170.png","171.png","172.png"],
              day_tc_array: ["163.png","164.png","165.png","166.png","167.png","168.png","169.png","170.png","171.png","172.png"],
              day_en_array: ["163.png","164.png","165.png","166.png","167.png","168.png","169.png","170.png","171.png","172.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 178,
              month_startY: 165,
              month_sc_array: ["151.png","152.png","153.png","154.png","155.png","156.png","157.png","158.png","159.png","160.png","161.png","162.png"],
              month_tc_array: ["151.png","152.png","153.png","154.png","155.png","156.png","157.png","158.png","159.png","160.png","161.png","162.png"],
              month_en_array: ["151.png","152.png","153.png","154.png","155.png","156.png","157.png","158.png","159.png","160.png","161.png","162.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 158,
              y: 190,
              week_en: ["173.png","174.png","175.png","176.png","177.png","178.png","179.png"],
              week_tc: ["173.png","174.png","175.png","176.png","177.png","178.png","179.png"],
              week_sc: ["173.png","174.png","175.png","176.png","177.png","178.png","179.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 248,
              y: 242,
              font_array: ["180.png","181.png","182.png","183.png","184.png","185.png","186.png","187.png","188.png","189.png"],
              padding: false,
              h_space: -35,
              invalid_image: '190.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 152,
              y: 305,
              font_array: ["191.png","192.png","193.png","194.png","195.png","196.png","197.png","198.png","199.png","200.png"],
              padding: false,
              h_space: -33,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 242,
              font_array: ["201.png","202.png","203.png","204.png","205.png","206.png","207.png","208.png","209.png","210.png"],
              padding: false,
              h_space: -34,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 190,
              y: 235,
              image_array: ["212.png","213.png","214.png","215.png","216.png","217.png","218.png","219.png","220.png","221.png","222.png","223.png","224.png","225.png","226.png","227.png","228.png","229.png","230.png","231.png","232.png","233.png","234.png","235.png","236.png","237.png","238.png","239.png","240.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 272,
              font_array: ["241.png","242.png","243.png","244.png","245.png","246.png","247.png","248.png","249.png","250.png"],
              padding: false,
              h_space: 0,
              unit_sc: '253.png',
              unit_tc: '253.png',
              unit_en: '253.png',
              negative_image: '252.png',
              invalid_image: '251.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}